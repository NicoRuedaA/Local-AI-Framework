```python filename: requirements.txt
Django==5.2.0
djangorestframework==3.15.4
celery==5.2.3
redis==4.5.4
psycopg2-binary==2.9.6
factory_boy==3.2.0
pytest==7.1.2
pytest-django==4.5.0
django-celery-results==2.2.0
```

```python filename: .env.example
DJANGO_SECRET_KEY=your_secret_key_here
DEBUG=True
ALLOWED_HOSTS=localhost 127.0.0.1 [::1]
DATABASE_URL=postgres://user:password@localhost/dbname
CELERY_BROKER_URL=redis://localhost:6379/0
CELERY_RESULT_BACKEND=redis://localhost:6379/0
```

```python filename: manage.py
#!/usr/bin/env python

"""Django's command-line utility for administrative tasks."""

import os
import sys

def main():
    """Run administrative tasks."""
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'nexo.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    execute_from_command_line(sys.argv)

if __name__ == '__main__':
    main()
```

```python filename: nexo/settings.py
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = os.getenv('DJANGO_SECRET_KEY')
DEBUG = os.getenv('DEBUG', 'False').lower() in ('true', '1', 't')
ALLOWED_HOSTS = os.getenv('ALLOWED_HOSTS', 'localhost 127.0.0.1 [::1]').split()

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework',
    'nexo.accounts',
    'nexo.features',
    'nexo.notifications',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'nexo.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'nexo.wsgi.application'

DATABASES = {
    'default': {
        'ENGINE': os.getenv('DATABASE_URL', 'django.db.backends.sqlite3'),
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_L10N = True
USE_TZ = True

STATIC_URL = '/static/'

CELERY_BROKER_URL = os.getenv('CELERY_BROKER_URL')
CELERY_RESULT_BACKEND = os.getenv('CELERY_RESULT_BACKEND')
CELERY_ACCEPT_CONTENT = ['json']
CELERY_TASK_SERIALIZER = 'json'
CELERY_RESULT_SERIALIZER = 'json'
CELERY_TIMEZONE = 'UTC'

REST_FRAMEWORK = {
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.IsAuthenticated',
    ],
}

CELERY_TASK_ALWAYS_EAGER = True
```

```python filename: nexo/urls.py
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/features/', include('nexo.features.urls')),
    path('api/notifications/', include('nexo.notifications.urls')),
]
```

```python filename: nexo/wsgi.py
"""
WSGI config for nexo project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/3.2/howto/deployment/wsgi/
"""

import os

from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'nexo.settings')

application = get_wsgi_application()
```

```python filename: nexo/accounts/models.py
from django.contrib.auth.models import AbstractUser
from django.db import models

class User(AbstractUser):
    pass
```

```python filename: nexo/features/models.py
from django.db import models
from django.contrib.auth.models import User
from .constants import STATUS_CHOICES

class FeatureRequest(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES)
    is_public = models.BooleanField(default=False)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)

class Vote(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    feature_request = models.ForeignKey(FeatureRequest, on_delete=models.CASCADE)
```

```python filename: nexo/notifications/models.py
from django.db import models

class Notification(models.Model):
    message = models.TextField()
    sent_at = models.DateTimeField(auto_now_add=True)
```

```python filename: nexo/accounts/views.py
from rest_framework import viewsets, status
from rest_framework.response import Response
from .models import User
from .serializers import UserSerializer

class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer
```

```python filename: nexo/features/views.py
from rest_framework import viewsets, status, permissions
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet
from .models import FeatureRequest, Vote
from .serializers import FeatureRequestSerializer, VoteSerializer

class FeatureViewSet(ModelViewSet):
    queryset = FeatureRequest.objects.all()
    serializer_class = FeatureRequestSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

class VoteAPIView(viewsets.ViewSet):
    permission_classes = [permissions.IsAuthenticated]

    def create(self, request):
        user = request.user
        feature_request_id = request.data.get('feature_request')
        try:
            feature_request = FeatureRequest.objects.select_for_update().get(id=feature_request_id)
        except FeatureRequest.DoesNotExist:
            return Response({'detail': 'Feature request not found'}, status=status.HTTP_404_NOT_FOUND)

        if not feature_request.is_public:
            return Response({'detail': 'This feature request is not public'}, status=status.HTTP_403_FORBIDDEN)

        vote, created = Vote.objects.get_or_create(user=user, feature_request=feature_request)
        if not created:
            return Response({'detail': 'You have already voted on this feature request'}, status=status.HTTP_400_BAD_REQUEST)

        send_notification_on_feature_request_status_change(feature_request_id)
        return Response({'detail': 'Vote successful'}, status=status.HTTP_201_CREATED)
```

```python filename: nexo/notifications/views.py
from rest_framework import viewsets, status
from rest_framework.response import Response
from .models import Notification
from .serializers import NotificationSerializer

class NotificationViewSet(viewsets.ModelViewSet):
    queryset = Notification.objects.all()
    serializer_class = NotificationSerializer
```

```python filename: nexo/accounts/serializers.py
from rest_framework import serializers
from django.contrib.auth.models import User

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'
```

```python filename: nexo/features/serializers.py
from rest_framework import serializers
from .models import FeatureRequest, Vote

class FeatureRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = FeatureRequest
        fields = '__all__'

class VoteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Vote
        fields = '__all__'
```

```python filename: nexo/notifications/serializers.py
from rest_framework import serializers
from .models import Notification

class NotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notification
        fields = '__all__'
```

```python filename: nexo/accounts/admin.py
from django.contrib import admin
from .models import User

admin.site.register(User)
```

```python filename: nexo/features/admin.py
from django.contrib import admin
from .models import FeatureRequest, Vote

admin.site.register(FeatureRequest)
admin.site.register(Vote)
```

```python filename: nexo/notifications/admin.py
from django.contrib import admin
from .models import Notification

admin.site.register(Notification)
```

```python filename: nexo/accounts/services.py
from django.db.models import F
from .models import FeatureRequest, Vote

def send_notification_on_feature_request_status_change(feature_request_id):
    try:
        feature_request = FeatureRequest.objects.select_for_update().get(id=feature_request_id)
        if feature_request.status == 'Lanzado':
            votes = Vote.objects.filter(feature_request=feature_request)
            for vote in votes:
                user = vote.user
                subject = f'Nueva funcionalidad lanzada: {feature_request.title}'
                message = f'Hola {user.username}, tu voto por la funcionalidad "{feature_request.title}" ha sido lanzado.'
                from_email = 'admin@nexo.com'
                recipient_list = [user.email]
                send_mail(subject, message, from_email, recipient_list)
    except FeatureRequest.DoesNotExist:
        pass
```

```python filename: nexo/features/services.py
from django.db.models import F
from .models import FeatureRequest, Vote

def send_notification_on_feature_request_status_change(feature_request_id):
    try:
        feature_request = FeatureRequest.objects.select_for_update().get(id=feature_request_id)
        if feature_request.status == 'Lanzado':
            votes = Vote.objects.filter(feature_request=feature_request)
            for vote in votes:
                user = vote.user
                subject = f'Nueva funcionalidad lanzada: {feature_request.title}'
                message = f'Hola {user.username}, tu voto por la funcionalidad "{feature_request.title}" ha sido lanzado.'
                from_email = 'admin@nexo.com'
                recipient_list = [user.email]
                send_mail(subject, message, from_email, recipient_list)
    except FeatureRequest.DoesNotExist:
        pass
```

```python filename: nexo/notifications/services.py
from django.core.mail import send_mail

def send_notification_on_feature_request_status_change(feature_request_id):
    try:
        feature_request = FeatureRequest.objects.select_for_update().get(id=feature_request_id)
        if feature_request.status == 'Lanzado':
            votes = Vote.objects.filter(feature_request=feature_request)
            for vote in votes:
                user = vote.user
                subject = f'Nueva funcionalidad lanzada: {feature_request.title}'
                message = f'Hola {user.username}, tu voto por la funcionalidad "{feature_request.title}" ha sido lanzado.'
                from_email = 'admin@nexo.com'
                recipient_list = [user.email]
                send_mail(subject, message, from_email, recipient_list)
    except FeatureRequest.DoesNotExist:
        pass
```

```python filename: nexo/accounts/tasks.py
from celery import shared_task
from django.core.mail import send_mail

@shared_task
def send_notification_on_feature_request_status_change(feature_request_id):
    try:
        feature_request = FeatureRequest.objects.select_for_update().get(id=feature_request_id)
        if feature_request.status == 'Lanzado':
            votes = Vote.objects.filter(feature_request=feature_request)
            for vote in votes:
                user = vote.user
                subject = f'Nueva funcionalidad lanzada: {feature_request.title}'
                message = f'Hola {user.username}, tu voto por la funcionalidad "{feature_request.title}" ha sido lanzado.'
                from_email = 'admin@nexo.com'
                recipient_list = [user.email]
                send_mail(subject, message, from_email, recipient_list)
    except FeatureRequest.DoesNotExist:
        pass
```

```python filename: nexo/features/tasks.py
from celery import shared_task
from django.core.mail import send_mail

@shared_task
def send_notification_on_feature_request_status_change(feature_request_id):
    try:
        feature_request = FeatureRequest.objects.select_for_update().get(id=feature_request_id)
        if feature_request.status == 'Lanzado':
            votes = Vote.objects.filter(feature_request=feature_request)
            for vote in votes:
                user = vote.user
                subject = f'Nueva funcionalidad lanzada: {feature_request.title}'
                message = f'Hola {user.username}, tu voto por la funcionalidad "{feature_request.title}" ha sido lanzado.'
                from_email = 'admin@nexo.com'
                recipient_list = [user.email]
                send_mail(subject, message, from_email, recipient_list)
    except FeatureRequest.DoesNotExist:
        pass
```

```python filename: nexo/notifications/tasks.py
from celery import shared_task
from django.core.mail import send_mail

@shared_task
def send_notification_on_feature_request_status_change(feature_request_id):
    try:
        feature_request = FeatureRequest.objects.select_for_update().get(id=feature_request_id)
        if feature_request.status == 'Lanzado':
            votes = Vote.objects.filter(feature_request=feature_request)
            for vote in votes:
                user = vote.user
                subject = f'Nueva funcionalidad lanzada: {feature_request.title}'
                message = f'Hola {user.username}, tu voto por la funcionalidad "{feature_request.title}" ha sido lanzado.'
                from_email = 'admin@nexo.com'
                recipient_list = [user.email]
                send_mail(subject, message, from_email, recipient_list)
    except FeatureRequest.DoesNotExist:
        pass
```

```python filename: nexo/accounts/tests.py
from django.test import TestCase
from rest_framework import status
from .models import User

class UserTestCase(TestCase):
    def test_user_creation(self):
        user = User.objects.create(username='testuser', email='test@example.com')
        self.assertEqual(user.username, 'testuser')
        self.assertEqual(user.email, 'test@example.com')

    def test_user_login(self):
        user = User.objects.create(username='testuser', password='password123')
        response = self.client.post('/api/auth/login/', {'username': 'testuser', 'password': 'password123'})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
```

```python filename: nexo/features/tests.py
from django.test import TestCase
from rest_framework import status
from .models import FeatureRequest

class FeatureRequestTestCase(TestCase):
    def test_feature_request_creation(self):
        user = User.objects.create(username='testuser', password='password123')
        response = self.client.post('/api/features/', {'title': 'Test Feature Request', 'description': 'This is a test feature request'}, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_feature_request_list(self):
        user = User.objects.create(username='testuser', password='password123')
        response = self.client.get('/api/features/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
```

```python filename: nexo/notifications/tests.py
from django.test import TestCase
from rest_framework import status

class NotificationTestCase(TestCase):
    def test_notification_creation(self):
        response = self.client.post('/api/notifications/', {'message': 'This is a test notification'}, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_notification_list(self):
        response = self.client.get('/api/notifications/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
```

```python filename: nexo/conftest.py
import factory
from django.contrib.auth.models import User
from .models import FeatureRequest, Vote

class UserFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = User

    username = factory.Sequence(lambda n: f'user{n}')
    email = factory.LazyAttribute(lambda user: f'{user.username}@example.com')
    password = factory.PostGenerationMethodCall('set_password', 'password')

class FeatureRequestFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = FeatureRequest

    title = factory.Sequence(lambda n: f'Feature Request {n}')
    description = factory.Sequence(lambda n: f'Description for feature request {n}')
    created_by = factory.SubFactory(UserFactory)

class VoteFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Vote

    user = factory.SubFactory(UserFactory)
    feature_request = factory.SubFactory(FeatureRequestFactory)
```

```python filename: README.md
# Nexo - Sistema de Votación y Notificación Automática

Nexo es una plataforma que permite a los usuarios votar en solicitudes de funcionalidad y recibir notificaciones cuando estas solicitudes cambien de estado. Es ideal para equipos que necesitan un sistema de gestión de características eficiente.

## Arquitectura

El sistema está compuesto por Django como backend, PostgreSQL como base de datos, Redis para tareas asíncronas y Celery para ejecutar tareas en segundo plano.

```plaintext
Django ↔ PostgreSQL ↔ Redis ↔ Celery Worker
```

## Requisitos previos

- Python 3.11+
- PostgreSQL 15+
- Redis 7+

## Instalación

Sigue estos pasos para clonar el repositorio, configurar el entorno y levantar el proyecto:

```bash
# Clona el repositorio
git clone https://github.com/tu-repositorio/nexo.git
cd nexo

# Crea un entorno virtual y activa it
python -m venv venv
source venv/bin/activate  # En Windows usa `venv\Scripts\activate`

# Instala las dependencias
pip install -r requirements.txt

# Configura las variables de entorno (.env)
cp .env.example .env
nano .env  # Ajusta los valores según tu configuración

# Realiza las migraciones
python manage.py migrate

# Crea un superusuario
python manage.py createsuperuser

# Levanta Redis (si no lo tienes instalado, puedes usar Docker)
docker-compose up -d redis

# Levanta el worker de Celery
celery -A nexo worker --loglevel=info

# Levanta el servidor Django
python manage.py runserver
```

## Variables de entorno

| Variable | Descripción | Ejemplo | Obligatoria |
|----------|-------------|---------|-----------|
| DJANGO_SECRET_KEY | Clave secreta para la configuración de Django | `your_secret_key_here` | Sí |
| DEBUG | Modo de depuración (True/False) | `True` | Sí |
| ALLOWED_HOSTS | Hosts permitidos | `localhost 127.0.0.1 [::1]` | Sí |
| DATABASE_URL | URL de la base de datos PostgreSQL | `postgres://user:password@localhost/dbname` | Sí |
| CELERY_BROKER_URL | URL del broker para Celery | `redis://localhost:6379/0` | Sí |

## Cómo ejecutar el proyecto

1. Crear entorno virtual e instalar dependencias
   ```bash
   python -m venv venv
   source venv/bin/activate  # En Windows usa `venv\Scripts\activate`
   pip install -r requirements.txt
   ```

2. Configurar variables de entorno
   ```bash
   cp .env.example .env
   nano .env  # Ajusta los valores según tu configuración
   ```

3. Realizar migraciones
   ```bash
   python manage.py migrate
   ```

4. Crear superusuario
   ```bash
   python manage.py createsuperuser
   ```

5. Levantar Redis (si no lo tienes instalado, puedes usar Docker)
   ```bash
   docker-compose up -d redis
   ```

6. Levantar worker de Celery
   ```bash
   celery -A nexo worker --loglevel=info
   ```

7. Levantar servidor Django
   ```bash
   python manage.py runserver
   ```
```

### Cómo ejecutar el proyecto

1. Crear entorno virtual e instalar dependencias
   ```bash
   python -m venv venv
   source venv/bin/activate  # En Windows usa `venv\Scripts\activate`
   pip install -r requirements.txt
   ```

2. Configurar variables de entorno
   ```bash
   cp .env.example .env
   nano .env  # Ajusta los valores según tu configuración
   ```

3. Realizar migraciones
   ```bash
   python manage.py migrate
   ```

4. Crear superusuario
   ```bash
   python manage.py createsuperuser
   ```

5. Levantar Redis (si no lo tienes instalado, puedes usar Docker)
   ```bash
   docker-compose up -d redis
   ```

6. Levantar worker de Celery
   ```bash
   celery -A nexo worker --loglevel=info
   ```

7. Levantar servidor Django
   ```bash
   python manage.py runserver
   ```