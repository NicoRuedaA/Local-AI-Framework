```plaintext
/mi_proyecto_actual/src/nexo/notifications/tasks.py
```

```python
from celery import shared_task
from django.core.mail import send_mail
from .models import FeatureRequest, Vote

@shared_task
def send_notification_on_feature_request_status_change(feature_request_id):
    feature_request = FeatureRequest.objects.get(id=feature_request_id)
    
    if feature_request.status == 'Lanzado':
        votes = Vote.objects.filter(feature_request=feature_request)
        
        for vote in votes:
            user = vote.user
            subject = f'Nueva funcionalidad lanzada: {feature_request.title}'
            message = f'Hola {user.username}, tu voto por la funcionalidad "{feature_request.title}" ha sido lanzado.'
            from_email = 'admin@nexo.com'
            recipient_list = [user.email]
            
            send_mail(subject, message, from_email, recipient_list)
```

### Cómo probarlo

1. **Instalación:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Migraciones:**
   ```bash
   python manage.py migrate
   ```

3. **Carga de Datos Iniciales (Opcional):**
   ```bash
   python manage.py loaddata initial_data.json
   ```

4. **Ejecución del Servidor:**
   ```bash
   python manage.py runserver
   ```

5. **Pruebas Unitarias:**
   ```bash
   python manage.py test
   ```

6. **Acceso al Panel de Administración:**
   - Visita `http://127.0.0.1:8000/admin/`
   - Inicia sesión con un usuario que tenga el rol de administrador.

7. **Ejecución del Tarea Celery (Manual):**
   ```bash
   celery -A nexo worker --loglevel=info
   ```

8. **Cambio de Estado de Solicitud:**
   - Cambia el estado de una solicitud de funcionalidad a "Lanzado" desde el panel de administración.
   - Verifica que se envíe un correo electrónico a todos los usuarios que votaron por la solicitud.

Este código implementa la tarea para enviar correos electrónicos cuando el estado de una solicitud de funcionalidad cambia a "Lanzado".