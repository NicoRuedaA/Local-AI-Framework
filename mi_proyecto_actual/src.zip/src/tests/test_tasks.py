import pytest
from celery import current_app

pytestmark = pytest.mark.django_db

def test_send_notification_on_feature_request_status_change_task(admin_user):
    feature_request_id = admin_user.feature_request.id
    send_notification_on_feature_request_status_change.delay(feature_request_id)
    assert len(current_app.control.inspect().active()) == 1
