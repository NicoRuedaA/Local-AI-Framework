import pytest
from rest_framework import status

pytestmark = pytest.mark.django_db

def test_admin_can_change_feature_request_status(admin_user, authenticated_api_client):
    url = f'/api/features/{admin_user.feature_request.id}/'
    data = {
        'status': 'Lanzado'
    }
    authenticated_api_client.force_authenticate(user=admin_user)
    response = authenticated_api_client.patch(url, data)
    assert response.status_code == status.HTTP_200_OK
