import pytest
from rest_framework import status

pytestmark = pytest.mark.django_db

def test_anonymous_user_cannot_create_feature_request(unauthenticated_api_client, feature_request_factory):
    url = '/api/features/'
    data = {
        'title': feature_request_factory.title,
        'description': feature_request_factory.description
    }
    response = unauthenticated_api_client.post(url, data)
    assert response.status_code == status.HTTP_401_UNAUTHORIZED

def test_standard_user_cannot_change_feature_request_status(standard_user, admin_user, authenticated_api_client):
    url = f'/api/features/{admin_user.feature_request.id}/'
    data = {
        'status': 'Lanzado'
    }
    authenticated_api_client.force_authenticate(user=standard_user)
    response = authenticated_api_client.patch(url, data)
    assert response.status_code == status.HTTP_403_FORBIDDEN

def test_user_cannot_edit_feature_request_of_another_user(admin_user, standard_user, authenticated_api_client):
    url = f'/api/features/{admin_user.feature_request.id}/'
    data = {
        'title': 'Updated Feature Request'
    }
    authenticated_api_client.force_authenticate(user=standard_user)
    response = authenticated_api_client.put(url, data)
    assert response.status_code == status.HTTP_403_FORBIDDEN
