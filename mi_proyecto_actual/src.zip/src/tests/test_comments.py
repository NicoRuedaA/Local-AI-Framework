import pytest
from rest_framework import status

pytestmark = pytest.mark.django_db

def test_authenticated_user_can_create_comment(authenticated_api_client):
    url = '/api/comments/'
    data = {
        'content': 'This is a comment',
        'parent': None,
        'feature_request': authenticated_api_client.user.feature_request.id
    }
    response = authenticated_api_client.post(url, data)
    assert response.status_code == status.HTTP_201_CREATED

def test_authenticated_user_can_create_nested_comment(authenticated_api_client):
    parent_comment = Comment.objects.create(
        content='Parent comment',
        parent=None,
        feature_request=authenticated_api_client.user.feature_request
    )
    url = '/api/comments/'
    data = {
        'content': 'Nested comment',
        'parent': parent_comment.id,
        'feature_request': authenticated_api_client.user.feature_request.id
    }
    response = authenticated_api_client.post(url, data)
    assert response.status_code == status.HTTP_201_CREATED

def test_authenticated_user_cannot_create_comment_without_feature_request(authenticated_api_client):
    url = '/api/comments/'
    data = {
        'content': 'This is a comment',
        'parent': None,
        'feature_request': None
    }
    response = authenticated_api_client.post(url, data)
    assert response.status_code == status.HTTP_400_BAD_REQUEST

def test_authenticated_user_cannot_create_comment_with_invalid_feature_request(authenticated_api_client):
    url = '/api/comments/'
    data = {
        'content': 'This is a comment',
        'parent': None,
        'feature_request': 9999
    }
    response = authenticated_api_client.post(url, data)
    assert response.status_code == status.HTTP_404_NOT_FOUND

def test_authenticated_user_cannot_create_comment_with_max_depth(authenticated_api_client):
    parent_comment = Comment.objects.create(
        content='Parent comment',
        parent=None,
        feature_request=authenticated_api_client.user.feature_request
    )
    for _ in range(10):
        parent_comment = Comment.objects.create(
            content=f'Nested comment {_}',
            parent=parent_comment.id,
            feature_request=authenticated_api_client.user.feature_request
        )
    url = '/api/comments/'
    data = {
        'content': 'This is a comment',
        'parent': parent_comment.id,
        'feature_request': authenticated_api_client.user.feature_request.id
    }
    response = authenticated_api_client.post(url, data)
    assert response.status_code == status.HTTP_400_BAD_REQUEST

def test_authenticated_user_cannot_create_comment_with_sql_injection_attempt(authenticated_api_client):
    url = '/api/comments/'
    data = {
        'content': "'; DROP TABLE comments; --",
        'parent': None,
        'feature_request': authenticated_api_client.user.feature_request.id
    }
    response = authenticated_api_client.post(url, data)
    assert response.status_code == status.HTTP_400_BAD_REQUEST
