import pytest
from rest_framework import status

pytestmark = pytest.mark.django_db

def test_authenticated_user_can_create_feature_request(authenticated_api_client):
    url = '/api/features/'
    data = {
        'title': 'New Feature Request',
        'description': 'Description of the new feature request'
    }
    response = authenticated_api_client.post(url, data)
    assert response.status_code == status.HTTP_201_CREATED

def test_authenticated_user_can_update_feature_request(authenticated_api_client):
    url = f'/api/features/{authenticated_api_client.user.feature_request.id}/'
    data = {
        'title': 'Updated Feature Request'
    }
    response = authenticated_api_client.put(url, data)
    assert response.status_code == status.HTTP_200_OK

def test_authenticated_user_can_delete_feature_request(authenticated_api_client):
    url = f'/api/features/{authenticated_api_client.user.feature_request.id}/'
    response = authenticated_api_client.delete(url)
    assert response.status_code == status.HTTP_204_NO_CONTENT
