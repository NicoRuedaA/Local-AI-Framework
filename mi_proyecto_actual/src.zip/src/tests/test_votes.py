import pytest
from rest_framework import status

pytestmark = pytest.mark.django_db

def test_authenticated_user_can_vote_for_feature_request(authenticated_api_client, feature_request):
    url = '/api/votes/'
    data = {
        'feature_request': feature_request.id
    }
    response = authenticated_api_client.post(url, data)
    assert response.status_code == status.HTTP_201_CREATED

def test_authenticated_user_cannot_vote_for_private_feature_request(authenticated_api_client, feature_request_factory):
    feature_request_factory.is_public = False
    feature_request_factory.save()
    url = '/api/votes/'
    data = {
        'feature_request': feature_request_factory.id
    }
    response = authenticated_api_client.post(url, data)
    assert response.status_code == status.HTTP_403_FORBIDDEN

def test_authenticated_user_cannot_vote_twice_for_same_feature_request(authenticated_api_client, vote):
    url = '/api/votes/'
    data = {
        'feature_request': vote.feature_request.id
    }
    response = authenticated_api_client.post(url, data)
    assert response.status_code == status.HTTP_400_BAD_REQUEST

def test_concurrent_votes_for_same_feature_request(authenticated_api_client, feature_request):
    url = '/api/votes/'
    data = {
        'feature_request': feature_request.id
    }
    
    def vote_user(user):
        authenticated_api_client.force_authenticate(user=user)
        response = authenticated_api_client.post(url, data)
        return response.status_code
    
    users = [authenticated_api_client.user] * 10
    results = list(map(vote_user, users))
    assert all(result == status.HTTP_201_CREATED for result in results)
