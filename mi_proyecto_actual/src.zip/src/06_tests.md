```python filename: conftest.py
import pytest
from django.contrib.auth.models import User
from .models import FeatureRequest, Vote

@pytest.fixture
def admin_user():
    return User.objects.create_superuser(username='admin', password='password')

@pytest.fixture
def standard_user():
    return User.objects.create_user(username='user', password='password')

@pytest.fixture
def feature_request(admin_user):
    return FeatureRequest.objects.create(
        title='New Feature Request',
        description='Description of the new feature request',
        created_by=admin_user,
        is_public=True
    )

@pytest.fixture
def vote(standard_user, feature_request):
    return Vote.objects.create(user=standard_user, feature_request=feature_request)

@pytest.fixture
def authenticated_api_client(admin_user):
    token = admin_user.auth_token.key
    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f'Token {token}')
    return client

@pytest.fixture
def unauthenticated_api_client():
    return APIClient()

@pytest.fixture
def feature_request_factory(factory_boy.django.DjangoModelFactory):
    class Meta:
        model = FeatureRequest
    
    title = factory.Sequence(lambda n: f'Feature Request {n}')
    description = factory.Sequence(lambda n: f'Description for feature request {n}')
    created_by = factory.SubFactory(UserFactory)
    is_public = True

@pytest.fixture
def vote_factory(factory_boy.django.DjangoModelFactory):
    class Meta:
        model = Vote
    
    user = factory.SubFactory(UserFactory)
    feature_request = factory.SubFactory(FeatureRequestFactory)

@pytest.fixture
def client():
    return APIClient()
```

```python filename: tests/test_auth.py
import pytest
from rest_framework import status

pytestmark = pytest.mark.django_db

def test_anonymous_user_cannot_create_feature_request(unauthenticated_api_client, feature_request_factory):
    url = '/api/features/'
    data = {
        'title': feature_request_factory.title,
        'description': feature_request_factory.description
    }
    response = unauthenticated_api_client.post(url, data)
    assert response.status_code == status.HTTP_401_UNAUTHORIZED

def test_standard_user_cannot_change_feature_request_status(standard_user, admin_user, authenticated_api_client):
    url = f'/api/features/{admin_user.feature_request.id}/'
    data = {
        'status': 'Lanzado'
    }
    authenticated_api_client.force_authenticate(user=standard_user)
    response = authenticated_api_client.patch(url, data)
    assert response.status_code == status.HTTP_403_FORBIDDEN

def test_user_cannot_edit_feature_request_of_another_user(admin_user, standard_user, authenticated_api_client):
    url = f'/api/features/{admin_user.feature_request.id}/'
    data = {
        'title': 'Updated Feature Request'
    }
    authenticated_api_client.force_authenticate(user=standard_user)
    response = authenticated_api_client.put(url, data)
    assert response.status_code == status.HTTP_403_FORBIDDEN
```

```python filename: tests/test_feature_requests.py
import pytest
from rest_framework import status

pytestmark = pytest.mark.django_db

def test_authenticated_user_can_create_feature_request(authenticated_api_client):
    url = '/api/features/'
    data = {
        'title': 'New Feature Request',
        'description': 'Description of the new feature request'
    }
    response = authenticated_api_client.post(url, data)
    assert response.status_code == status.HTTP_201_CREATED

def test_authenticated_user_can_update_feature_request(authenticated_api_client):
    url = f'/api/features/{authenticated_api_client.user.feature_request.id}/'
    data = {
        'title': 'Updated Feature Request'
    }
    response = authenticated_api_client.put(url, data)
    assert response.status_code == status.HTTP_200_OK

def test_authenticated_user_can_delete_feature_request(authenticated_api_client):
    url = f'/api/features/{authenticated_api_client.user.feature_request.id}/'
    response = authenticated_api_client.delete(url)
    assert response.status_code == status.HTTP_204_NO_CONTENT
```

```python filename: tests/test_votes.py
import pytest
from rest_framework import status

pytestmark = pytest.mark.django_db

def test_authenticated_user_can_vote_for_feature_request(authenticated_api_client, feature_request):
    url = '/api/votes/'
    data = {
        'feature_request': feature_request.id
    }
    response = authenticated_api_client.post(url, data)
    assert response.status_code == status.HTTP_201_CREATED

def test_authenticated_user_cannot_vote_for_private_feature_request(authenticated_api_client, feature_request_factory):
    feature_request_factory.is_public = False
    feature_request_factory.save()
    url = '/api/votes/'
    data = {
        'feature_request': feature_request_factory.id
    }
    response = authenticated_api_client.post(url, data)
    assert response.status_code == status.HTTP_403_FORBIDDEN

def test_authenticated_user_cannot_vote_twice_for_same_feature_request(authenticated_api_client, vote):
    url = '/api/votes/'
    data = {
        'feature_request': vote.feature_request.id
    }
    response = authenticated_api_client.post(url, data)
    assert response.status_code == status.HTTP_400_BAD_REQUEST

def test_concurrent_votes_for_same_feature_request(authenticated_api_client, feature_request):
    url = '/api/votes/'
    data = {
        'feature_request': feature_request.id
    }
    
    def vote_user(user):
        authenticated_api_client.force_authenticate(user=user)
        response = authenticated_api_client.post(url, data)
        return response.status_code
    
    users = [authenticated_api_client.user] * 10
    results = list(map(vote_user, users))
    assert all(result == status.HTTP_201_CREATED for result in results)
```

```python filename: tests/test_comments.py
import pytest
from rest_framework import status

pytestmark = pytest.mark.django_db

def test_authenticated_user_can_create_comment(authenticated_api_client):
    url = '/api/comments/'
    data = {
        'content': 'This is a comment',
        'parent': None,
        'feature_request': authenticated_api_client.user.feature_request.id
    }
    response = authenticated_api_client.post(url, data)
    assert response.status_code == status.HTTP_201_CREATED

def test_authenticated_user_can_create_nested_comment(authenticated_api_client):
    parent_comment = Comment.objects.create(
        content='Parent comment',
        parent=None,
        feature_request=authenticated_api_client.user.feature_request
    )
    url = '/api/comments/'
    data = {
        'content': 'Nested comment',
        'parent': parent_comment.id,
        'feature_request': authenticated_api_client.user.feature_request.id
    }
    response = authenticated_api_client.post(url, data)
    assert response.status_code == status.HTTP_201_CREATED

def test_authenticated_user_cannot_create_comment_without_feature_request(authenticated_api_client):
    url = '/api/comments/'
    data = {
        'content': 'This is a comment',
        'parent': None,
        'feature_request': None
    }
    response = authenticated_api_client.post(url, data)
    assert response.status_code == status.HTTP_400_BAD_REQUEST

def test_authenticated_user_cannot_create_comment_with_invalid_feature_request(authenticated_api_client):
    url = '/api/comments/'
    data = {
        'content': 'This is a comment',
        'parent': None,
        'feature_request': 9999
    }
    response = authenticated_api_client.post(url, data)
    assert response.status_code == status.HTTP_404_NOT_FOUND

def test_authenticated_user_cannot_create_comment_with_max_depth(authenticated_api_client):
    parent_comment = Comment.objects.create(
        content='Parent comment',
        parent=None,
        feature_request=authenticated_api_client.user.feature_request
    )
    for _ in range(10):
        parent_comment = Comment.objects.create(
            content=f'Nested comment {_}',
            parent=parent_comment.id,
            feature_request=authenticated_api_client.user.feature_request
        )
    url = '/api/comments/'
    data = {
        'content': 'This is a comment',
        'parent': parent_comment.id,
        'feature_request': authenticated_api_client.user.feature_request.id
    }
    response = authenticated_api_client.post(url, data)
    assert response.status_code == status.HTTP_400_BAD_REQUEST

def test_authenticated_user_cannot_create_comment_with_sql_injection_attempt(authenticated_api_client):
    url = '/api/comments/'
    data = {
        'content': "'; DROP TABLE comments; --",
        'parent': None,
        'feature_request': authenticated_api_client.user.feature_request.id
    }
    response = authenticated_api_client.post(url, data)
    assert response.status_code == status.HTTP_400_BAD_REQUEST
```

```python filename: tests/test_admin.py
import pytest
from rest_framework import status

pytestmark = pytest.mark.django_db

def test_admin_can_change_feature_request_status(admin_user, authenticated_api_client):
    url = f'/api/features/{admin_user.feature_request.id}/'
    data = {
        'status': 'Lanzado'
    }
    authenticated_api_client.force_authenticate(user=admin_user)
    response = authenticated_api_client.patch(url, data)
    assert response.status_code == status.HTTP_200_OK
```

```python filename: tests/test_tasks.py
import pytest
from celery import current_app

pytestmark = pytest.mark.django_db

def test_send_notification_on_feature_request_status_change_task(admin_user):
    feature_request_id = admin_user.feature_request.id
    send_notification_on_feature_request_status_change.delay(feature_request_id)
    assert len(current_app.control.inspect().active()) == 1
```

Para ejecutar los tests, asegúrate de tener `pytest` y `pytest-django` instalados:

```bash
pip install pytest pytest-django
```

Luego puedes correr los tests con:

```bash
pytest --cov=. --cov-report=html
```

Esto generará una cubertura HTML en el directorio `htmlcov`.