```python
from django.test import TestCase
from unittest.mock import patch, MagicMock
from .tasks import send_notification_on_feature_request_status_change, get_feature_request, is_feature_request_ready_to_notify, notify_users

class TestFeatureRequestNotifications(TestCase):
    @patch('nexo.notifications.tasks.FeatureRequest.objects.get')
    def test_send_notification_on_feature_request_status_change_happy_path(self, mock_get):
        # Arrange
        feature_request_id = 1
        feature_request = MagicMock(status='Lanzado', is_public=True)
        mock_get.return_value = feature_request
        
        votes = [
            MagicMock(user=MagicMock(username='user1'), feature_request=feature_request),
            MagicMock(user=MagicMock(username='user2'), feature_request=feature_request)
        ]
        
        with patch('nexo.notifications.tasks.Vote.objects.filter') as mock_filter:
            mock_filter.return_value = votes
            
            with patch('nexo.notifications.tasks.send_mail') as mock_send_mail:
                # Act
                send_notification_on_feature_request_status_change(feature_request_id)
                
                # Assert
                mock_get.assert_called_once_with(id=feature_request_id)
                self.assertTrue(is_feature_request_ready_to_notify(feature_request))
                mock_filter.assert_called_once_with(feature_request=feature_request)
                self.assertEqual(mock_send_mail.call_count, 2)
                mock_send_mail.assert_any_call(
                    subject='Nueva funcionalidad lanzada: Feature Request Title',
                    message='Hola user1, tu voto por la funcionalidad "Feature Request Title" ha sido lanzado.',
                    from_email='admin@nexo.com',
                    recipient_list=['user1@example.com']
                )
                mock_send_mail.assert_any_call(
                    subject='Nueva funcionalidad lanzada: Feature Request Title',
                    message='Hola user2, tu voto por la funcionalidad "Feature Request Title" ha sido lanzado.',
                    from_email='admin@nexo.com',
                    recipient_list=['user2@example.com']
                )

    @patch('nexo.notifications.tasks.FeatureRequest.objects.get')
    def test_send_notification_on_feature_request_status_change_edge_case_not_public(self, mock_get):
        # Arrange
        feature_request_id = 1
        feature_request = MagicMock(status='Lanzado', is_public=False)
        mock_get.return_value = feature_request
        
        with patch('nexo.notifications.tasks.Vote.objects.filter') as mock_filter:
            mock_filter.return_value = []
            
            # Act & Assert
            send_notification_on_feature_request_status_change(feature_request_id)
            self.assertFalse(is_feature_request_ready_to_notify(feature_request))
            mock_filter.assert_not_called()

    @patch('nexo.notifications.tasks.FeatureRequest.objects.get')
    def test_send_notification_on_feature_request_status_change_edge_case_no_votes(self, mock_get):
        # Arrange
        feature_request_id = 1
        feature_request = MagicMock(status='Lanzado', is_public=True)
        mock_get.return_value = feature_request
        
        with patch('nexo.notifications.tasks.Vote.objects.filter') as mock_filter:
            mock_filter.return_value = []
            
            # Act & Assert
            send_notification_on_feature_request_status_change(feature_request_id)
            self.assertEqual(mock_send_mail.call_count, 0)

    @patch('nexo.notifications.tasks.FeatureRequest.objects.get')
    def test_send_notification_on_feature_request_status_change_error_case_feature_request_not_found(self, mock_get):
        # Arrange
        feature_request_id = 1
        mock_get.side_effect = FeatureRequest.DoesNotExist
        
        # Act & Assert
        with self.assertLogs(level='INFO') as log:
            send_notification_on_feature_request_status_change(feature_request_id)
            self.assertIn("FeatureRequest con ID 1 no encontrado", log.output)

    @patch('nexo.notifications.tasks.FeatureRequest.objects.get')
    def test_send_notification_on_feature_request_status_change_error_case_invalid_status(self, mock_get):
        # Arrange
        feature_request_id = 1
        feature_request = MagicMock(status='Rechazado', is_public=True)
        mock_get.return_value = feature_request
        
        with patch('nexo.notifications.tasks.Vote.objects.filter') as mock_filter:
            mock_filter.return_value = []
            
            # Act & Assert
            send_notification_on_feature_request_status_change(feature_request_id)
            self.assertFalse(is_feature_request_ready_to_notify(feature_request))
            mock_filter.assert_not_called()

    @patch('nexo.notifications.tasks.FeatureRequest.objects.get')
    def test_send_notification_on_feature_request_status_change_error_case_invalid_user_email(self, mock_get):
        # Arrange
        feature_request_id = 1
        feature_request = MagicMock(status='Lanzado', is_public=True)
        mock_get.return_value = feature_request
        
        votes = [
            MagicMock(user=MagicMock(username='user1'), feature_request=feature_request),
            MagicMock(user=MagicMock(username='user2', email=None), feature_request=feature_request)
        ]
        
        with patch('nexo.notifications.tasks.Vote.objects.filter') as mock_filter:
            mock_filter.return_value = votes
            
            # Act & Assert
            send_notification_on_feature_request_status_change(feature_request_id)
            self.assertEqual(mock_send_mail.call_count, 1)

    @patch('nexo.notifications.tasks.FeatureRequest.objects.get')
    def test_get_feature_request_happy_path(self, mock_get):
        # Arrange
        feature_request_id = 1
        feature_request = MagicMock()
        mock_get.return_value = feature_request
        
        # Act
        result = get_feature_request(feature_request_id)
        
        # Assert
        self.assertEqual(result, feature_request)
        mock_get.assert_called_once_with(id=feature_request_id)

    @patch('nexo.notifications.tasks.FeatureRequest.objects.get')
    def test_get_feature_request_error_case_feature_request_not_found(self, mock_get):
        # Arrange
        feature_request_id = 1
        mock_get.side_effect = FeatureRequest.DoesNotExist
        
        # Act & Assert
        with self.assertLogs(level='INFO') as log:
            result = get_feature_request(feature_request_id)
            self.assertIsNone(result)
            self.assertIn("FeatureRequest con ID 1 no encontrado", log.output)

    @patch('nexo.notifications.tasks.FeatureRequest.objects.get')
    def test_is_feature_request_ready_to_notify_happy_path(self, mock_get):
        # Arrange
        feature_request = MagicMock(status='Lanzado', is_public=True)
        
        # Act
        result = is_feature_request_ready_to_notify(feature_request)
        
        # Assert
        self.assertTrue(result)

    @patch('nexo.notifications.tasks.FeatureRequest.objects.get')
    def test_is_feature_request_ready_to_notify_error_case_invalid_status(self, mock_get):
        # Arrange
        feature_request = MagicMock(status='Rechazado', is_public=True)
        
        # Act
        result = is_feature_request_ready_to_notify(feature_request)
        
        # Assert
        self.assertFalse(result)

    @patch('nexo.notifications.tasks.FeatureRequest.objects.get')
    def test_is_feature_request_ready_to_notify_error_case_not_public(self, mock_get):
        # Arrange
        feature_request = MagicMock(status='Lanzado', is_public=False)
        
        # Act
        result = is_feature_request_ready_to_notify(feature_request)
        
        # Assert
        self.assertFalse(result)

    @patch('nexo.notifications.tasks.FeatureRequest.objects.get')
    def test_notify_users_happy_path(self, mock_get):
        # Arrange
        feature_request_id = 1
        feature_request = MagicMock(status='Lanzado', is_public=True)
        mock_get.return_value = feature_request
        
        votes = [
            MagicMock(user=MagicMock(username='user1'), feature_request=feature_request),
            MagicMock(user=MagicMock(username='user2'), feature_request=feature_request)
        ]
        
        with patch('nexo.notifications.tasks.Vote.objects.filter') as mock_filter:
            mock_filter.return_value = votes
            
            with patch('nexo.notifications.tasks.send_mail') as mock_send_mail:
                # Act
                notify_users(feature_request)
                
                # Assert
                self.assertEqual(mock_send_mail.call_count, 2)
                mock_send_mail.assert_any_call(
                    subject='Nueva funcionalidad lanzada: Feature Request Title',
                    message='Hola user1, tu voto por la funcionalidad "Feature Request Title" ha sido lanzado.',
                    from_email='admin@nexo.com',
                    recipient_list=['user1@example.com']
                )
                mock_send_mail.assert_any_call(
                    subject='Nueva funcionalidad lanzada: Feature Request Title',
                    message='Hola user2, tu voto por la funcionalidad "Feature Request Title" ha sido lanzado.',
                    from_email='admin@nexo.com',
                    recipient_list=['user2@example.com']
                )

    @patch('nexo.notifications.tasks.FeatureRequest.objects.get')
    def test_notify_users_error_case_invalid_user_email(self, mock_get):
        # Arrange
        feature_request_id = 1
        feature_request = MagicMock(status='Lanzado', is_public=True)
        mock_get.return_value = feature_request
        
        votes = [
            MagicMock(user=MagicMock(username='user1'), feature_request=feature_request),
            MagicMock(user=MagicMock(username='user2', email=None), feature_request=feature_request)
        ]
        
        with patch('nexo.notifications.tasks.Vote.objects.filter') as mock_filter:
            mock_filter.return_value = votes
            
            with patch('nexo.notifications.tasks.send_mail') as mock_send_mail:
                # Act
                notify_users(feature_request)
                
                # Assert
                self.assertEqual(mock_send_mail.call_count, 1)

# Resumen de escenarios cubiertos:
- Happy path: 
  - send_notification_on_feature_request_status_change_happy_path
  - get_feature_request_happy_path
  - is_feature_request_ready_to_notify_happy_path
  - notify_users_happy_path

- Edge cases:
  - send_notification_on_feature_request_status_change_edge_case_not_public
  - send_notification_on_feature_request_status_change_edge_case_no_votes
  - send_notification_on_feature_request_status_change_error_case_invalid_user_email

- Gestión de errores:
  - send_notification_on_feature_request_status_change_error_case_feature_request_not_found
  - send_notification_on_feature_request_status_change_error_case_invalid_status
  - get_feature_request_error_case_feature_request_not_found
  - is_feature_request_ready_to_notify_error_case_invalid_status
  - is_feature_request_ready_to_notify_error_case_not_public
  - notify_users_error_case_invalid_user_email

- Integraciones:
  - send_notification_on_feature_request_status_change_happy_path (mock de send_mail)
```

Este conjunto de tests cubre los escenarios principales y edge cases para la tarea `send_notification_on_feature_request_status_change`. Incluye pruebas para el camino feliz, casos extremos, manejo de errores y mocks para las dependencias externas.