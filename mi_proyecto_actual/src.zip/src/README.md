
# Nexo - Sistema de Votación y Notificación Automática

Nexo es una plataforma que permite a los usuarios votar en solicitudes de funcionalidad y recibir notificaciones cuando estas solicitudes cambien de estado. Es ideal para equipos que necesitan un sistema de gestión de características eficiente.

## Arquitectura
