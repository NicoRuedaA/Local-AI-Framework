## 1. README.md

**Descripción del Proyecto**
Este proyecto es una implementación de una notificación automática cuando el estado de una solicitud de funcionalidad cambia a "Lanzado". Las solicitudes son votadas por los usuarios, y cuando se cumple cierto criterio (estado "Lanzado" y la solicitud sea pública), un correo electrónico es enviado a todos los usuarios que votaron.

**Requisitos Previos y Versiones**
- Python 3.11+
- Django 5.x
- Django REST Framework (DRF)
- PostgreSQL
- Celery
- Redis

**Instalación Paso a Paso**

1. Clona el repositorio:
   ```bash
   git clone https://github.com/tu-repositorio/nexo.git
   cd nexo
   ```

2. Crea un entorno virtual y activa it:
   ```bash
   python -m venv venv
   source venv/bin/activate  # En Windows usa `venv\Scripts\activate`
   ```

3. Instala las dependencias:
   ```bash
   pip install -r requirements.txt
   ```

4. Configura la base de datos (por ejemplo, PostgreSQL) y actualiza el archivo `settings.py` con los detalles de conexión.

5. Realiza las migraciones:
   ```bash
   python manage.py migrate
   ```

6. Carga datos iniciales (opcional):
   ```bash
   python manage.py loaddata initial_data.json
   ```

7. Inicializa el servidor Celery:
   ```bash
   celery -A nexo worker --loglevel=info
   ```

8. Ejecuta la aplicación:
   ```bash
   python manage.py runserver
   ```

**Ejemplo de Uso Rápido**

1. Visita `http://127.0.0.1:8000/admin/` y inicia sesión con un usuario que tenga el rol de administrador.
2. Cambia el estado de una solicitud de funcionalidad a "Lanzado".
3. Verifica que se envíe un correo electrónico a todos los usuarios que votaron por la solicitud.

**Estructura del Proyecto**

```
/nexo
├── /01_spec
│   ├── README.md
│   └── requirements.txt
├── /src
│   ├── /nexo
│   │   ├── __init__.py
│   │   ├── settings.py
│   │   ├── urls.py
│   │   ├── wsgi.py
│   │   ├── /accounts
│   │   │   ├── __init__.py
│   │   │   ├── apps.py
│   │   │   ├── models.py
│   │   │   ├── views.py
│   │   │   └── serializers.py
│   │   ├── /features
│   │   │   ├── __init__.py
│   │   │   ├── apps.py
│   │   │   ├── models.py
│   │   │   ├── views.py
│   │   │   ├── serializers.py
│   │   │   └── permissions.py
│   │   ├── /notifications
│   │   │   ├── __init__.py
│   │   │   ├── apps.py
│   │   │   ├── tasks.py
│   │   │   └── models.py
│   │   ├── /users
│   │   │   ├── __init__.py
│   │   │   ├── apps.py
│   │   │   ├── models.py
│   │   │   ├── views.py
│   │   │   └── serializers.py
│   │   ├── /utils
│   │   │   ├── __init__.py
│   │   │   ├── constants.py
│   │   │   └── helpers.py
│   │   ├── /migrations
│   │   │   ├── 0001_initial.py
│   │   │   └── ...
│   │   ├── manage.py
│   │   └── tests
│   │       ├── __init__.py
│   │       ├── test_models.py
│   │       ├── test_views.py
│   │       └── ...
├── /requirements.txt
└── README.md
```

**Variables de Entorno Necesarias**

| Nombre            | Descripción                           | Ejemplo              | Obligatoria |
|-------------------|---------------------------------------|----------------------|-------------|
| `DATABASE_URL`    | URL de la base de datos (PostgreSQL)   | `postgres://user:password@localhost/dbname` | Sí          |
| `DJANGO_SECRET_KEY`| Clave secreta para Django              | `your-secret-key-here` | Sí          |

**Cómo Ejecutar los Tests**

1. Asegúrate de que todas las dependencias estén instaladas.
2. Ejecuta los tests:
   ```bash
   python manage.py test
   ```

## 2. Documentación inline

### `send_notification_on_feature_request_status_change` (tasks.py)

**Descripción**
Tarea Celery para enviar una notificación de correo electrónico cuando el estado de una solicitud de funcionalidad cambia a "Lanzado".

**Parámetros**
- `feature_request_id`: ID del objeto `FeatureRequest`.

**Retorno**
- No retorna nada.

**Excepciones Posibles**
- `FeatureRequest.DoesNotExist`: Si no se encuentra el objeto `FeatureRequest` en la base de datos.

**Ejemplo de Uso**
```python
from nexo.notifications.tasks import send_notification_on_feature_request_status_change

send_notification_on_feature_request_status_change(feature_request_id=1)
```

### `get_feature_request` (tasks.py)

**Descripción**
Recupera un objeto `FeatureRequest` a partir de su ID.

**Parámetros**
- `feature_request_id`: ID del objeto `FeatureRequest`.

**Retorno**
- Un objeto `FeatureRequest`.
- `None`: Si no se encuentra el objeto en la base de datos.

**Excepciones Posibles**
- `FeatureRequest.DoesNotExist`: Si no se encuentra el objeto `FeatureRequest` en la base de datos.

**Ejemplo de Uso**
```python
from nexo.notifications.tasks import get_feature_request

feature_request = get_feature_request(feature_request_id=1)
```

### `is_feature_request_ready_to_notify` (tasks.py)

**Descripción**
Verifica si una solicitud de funcionalidad está lista para enviar una notificación.

**Parámetros**
- `feature_request`: Objeto `FeatureRequest`.

**Retorno**
- `True`: Si la solicitud está lista para enviar una notificación.
- `False`: En caso contrario.

**Excepciones Posibles**
- Ninguna.

**Ejemplo de Uso**
```python
from nexo.notifications.tasks import is_feature_request_ready_to_notify

feature_request = FeatureRequest.objects.get(id=1)
is_ready = is_feature_request_ready_to_notify(feature_request)
```

### `notify_users` (tasks.py)

**Descripción**
Envía correos electrónicos a los usuarios que votaron por una solicitud de funcionalidad.

**Parámetros**
- `feature_request`: Objeto `FeatureRequest`.

**Retorno**
- No retorna nada.

**Excepciones Posibles**
- Ninguna.

**Ejemplo de Uso**
```python
from nexo.notifications.tasks import notify_users

feature_request = FeatureRequest.objects.get(id=1)
notify_users(feature_request)
```

## 3. Guía de API (si aplica)

En este proyecto no se implementan endpoints específicos, por lo que no se requiere una guía de API.