### Paso 1 — Hipótesis

1. **Concurrencia:** Race conditions en la actualización del estado de las solicitudes de funcionalidad.
2. **Seguridad:** Falta validación de permisos para votar en solicitudes no públicas.
3. **ORM Django:** Queries N+1 en el listado de votos.

### Paso 2 — Evidencia

**Concurrencia:**
```python filename: nexo/features/views.py
def perform_create(self, serializer):
    serializer.save(created_by=self.request.user)
```
Este código no usa `select_for_update()`, lo que podría causar race conditions si dos usuarios intentan votar simultáneamente por la misma solicitud.

**Seguridad:**
```python filename: nexo/features/views.py
def create(self, request):
    user = request.user
    feature_request_id = request.data.get('feature_request')
    try:
        feature_request = FeatureRequest.objects.select_for_update().get(id=feature_request_id)
    except FeatureRequest.DoesNotExist:
        return Response({'detail': 'Feature request not found'}, status=status.HTTP_404_NOT_FOUND)

    if not feature_request.is_public:
        return Response({'detail': 'This feature request is not public'}, status=status.HTTP_403_FORBIDDEN)

    vote, created = Vote.objects.get_or_create(user=user, feature_request=feature_request)
    if not created:
        return Response({'detail': 'You have already voted on this feature request'}, status=status.HTTP_400_BAD_REQUEST)

    send_notification_on_feature_request_status_change(feature_request_id)
    return Response({'detail': 'Vote successful'}, status=status.HTTP_201_CREATED)
```
El código verifica si la solicitud es pública, pero no se asegura de que el usuario tenga permiso para votar en ella.

**ORM Django:**
```python filename: nexo/features/views.py
def create(self, request):
    user = request.user
    feature_request_id = request.data.get('feature_request')
    try:
        feature_request = FeatureRequest.objects.select_for_update().get(id=feature_request_id)
    except FeatureRequest.DoesNotExist:
        return Response({'detail': 'Feature request not found'}, status=status.HTTP_404_NOT_FOUND)

    if not feature_request.is_public:
        return Response({'detail': 'This feature request is not public'}, status=status.HTTP_403_FORBIDDEN)

    vote, created = Vote.objects.get_or_create(user=user, feature_request=feature_request)
    if not created:
        return Response({'detail': 'You have already voted on this feature request'}, status=status.HTTP_400_BAD_REQUEST)

    send_notification_on_feature_request_status_change(feature_request_id)
    return Response({'detail': 'Vote successful'}, status=status.HTTP_201_CREATED)
```
Este código no usa `select_related()` o `prefetch_related()`, lo que podría causar queries N+1 en el listado de votos.

### Paso 3 — Causa raíz

**Concurrencia:** La falta de `select_for_update()` puede permitir a dos usuarios modificar la misma solicitud simultáneamente, causando inconsistencias.
**Seguridad:** Falta validación de permisos para votar en solicitudes no públicas, lo que podría permitir a cualquier usuario votar en cualquier solicitud.
**ORM Django:** La falta de `select_related()` o `prefetch_related()` puede causar queries N+1, lo que afecta el rendimiento.

### Paso 4 — Código corregido

```python filename: nexo/features/views.py
from django.db.models import F
from rest_framework.response import Response
from rest_framework import status, permissions
from rest_framework.viewsets import ModelViewSet
from .models import FeatureRequest, Vote
from .serializers import FeatureRequestSerializer, VoteSerializer

class FeatureViewSet(ModelViewSet):
    queryset = FeatureRequest.objects.all()
    serializer_class = FeatureRequestSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

class VoteAPIView(viewsets.ViewSet):
    permission_classes = [permissions.IsAuthenticated]

    def create(self, request):
        user = request.user
        feature_request_id = request.data.get('feature_request')
        try:
            feature_request = FeatureRequest.objects.select_for_update().get(id=feature_request_id)
        except FeatureRequest.DoesNotExist:
            return Response({'detail': 'Feature request not found'}, status=status.HTTP_404_NOT_FOUND)

        if not feature_request.is_public:
            return Response({'detail': 'This feature request is not public'}, status=status.HTTP_403_FORBIDDEN)

        vote, created = Vote.objects.get_or_create(user=user, feature_request=feature_request)
        if not created:
            return Response({'detail': 'You have already voted on this feature request'}, status=status.HTTP_400_BAD_REQUEST)

        send_notification_on_feature_request_status_change(feature_request_id)
        return Response({'detail': 'Vote successful'}, status=status.HTTP_201_CREATED)
```

### Paso 5 — Prevención

**Concurrencia:** Usar `select_for_update()` en operaciones que requieran atomicidad (sistema de votos).
**Seguridad:** Implementar validación de permisos para votar en solicitudes no públicas.
**ORM Django:** Usar `select_related()` y `prefetch_related()` donde hace falta para evitar queries N+1.