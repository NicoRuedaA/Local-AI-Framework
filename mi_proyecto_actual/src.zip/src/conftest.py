import pytest
from django.contrib.auth.models import User
from .models import FeatureRequest, Vote

@pytest.fixture
def admin_user():
    return User.objects.create_superuser(username='admin', password='password')

@pytest.fixture
def standard_user():
    return User.objects.create_user(username='user', password='password')

@pytest.fixture
def feature_request(admin_user):
    return FeatureRequest.objects.create(
        title='New Feature Request',
        description='Description of the new feature request',
        created_by=admin_user,
        is_public=True
    )

@pytest.fixture
def vote(standard_user, feature_request):
    return Vote.objects.create(user=standard_user, feature_request=feature_request)

@pytest.fixture
def authenticated_api_client(admin_user):
    token = admin_user.auth_token.key
    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f'Token {token}')
    return client

@pytest.fixture
def unauthenticated_api_client():
    return APIClient()

@pytest.fixture
def feature_request_factory(factory_boy.django.DjangoModelFactory):
    class Meta:
        model = FeatureRequest
    
    title = factory.Sequence(lambda n: f'Feature Request {n}')
    description = factory.Sequence(lambda n: f'Description for feature request {n}')
    created_by = factory.SubFactory(UserFactory)
    is_public = True

@pytest.fixture
def vote_factory(factory_boy.django.DjangoModelFactory):
    class Meta:
        model = Vote
    
    user = factory.SubFactory(UserFactory)
    feature_request = factory.SubFactory(FeatureRequestFactory)

@pytest.fixture
def client():
    return APIClient()
