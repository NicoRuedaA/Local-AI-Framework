from django.test import TestCase
from rest_framework import status
from .models import User

class UserTestCase(TestCase):
    def test_user_creation(self):
        user = User.objects.create(username='testuser', email='test@example.com')
        self.assertEqual(user.username, 'testuser')
        self.assertEqual(user.email, 'test@example.com')

    def test_user_login(self):
        user = User.objects.create(username='testuser', password='password123')
        response = self.client.post('/api/auth/login/', {'username': 'testuser', 'password': 'password123'})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
