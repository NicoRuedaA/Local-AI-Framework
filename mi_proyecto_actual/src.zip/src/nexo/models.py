from django.db import models from django.contrib.auth.models import User

class FeatureRequest(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    status = models.CharField(max_length=10, choices=[('Bajo revisión', 'Bajo revisión'), ('Planeado', 'Planeado'), ('Lanzado', 'Lanzado')])
    is_public = models.BooleanField(default=False)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)

class Vote(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    feature_request = models.ForeignKey(FeatureRequest, on_delete=models.CASCADE)
