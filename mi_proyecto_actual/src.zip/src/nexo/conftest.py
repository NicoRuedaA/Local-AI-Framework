import factory
from django.contrib.auth.models import User
from .models import FeatureRequest, Vote

class UserFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = User

    username = factory.Sequence(lambda n: f'user{n}')
    email = factory.LazyAttribute(lambda user: f'{user.username}@example.com')
    password = factory.PostGenerationMethodCall('set_password', 'password')

class FeatureRequestFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = FeatureRequest

    title = factory.Sequence(lambda n: f'Feature Request {n}')
    description = factory.Sequence(lambda n: f'Description for feature request {n}')
    created_by = factory.SubFactory(UserFactory)

class VoteFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Vote

    user = factory.SubFactory(UserFactory)
    feature_request = factory.SubFactory(FeatureRequestFactory)
