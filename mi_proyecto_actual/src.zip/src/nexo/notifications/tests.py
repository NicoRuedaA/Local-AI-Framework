from django.test import TestCase
from rest_framework import status

class NotificationTestCase(TestCase):
    def test_notification_creation(self):
        response = self.client.post('/api/notifications/', {'message': 'This is a test notification'}, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_notification_list(self):
        response = self.client.get('/api/notifications/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
