from celery import shared_task from django.core.mail import send_mail from .models import FeatureRequest, Vote

@shared_task(bind=True)
def send_notification_on_feature_request_status_change(self, feature_request_id):
    try:
        feature_request = FeatureRequest.objects.select_for_update().get(id=feature_request_id)
        if feature_request.status == 'Lanzado' and feature_request.is_public:
            votes = Vote.objects.filter(feature_request=feature_request)
            for vote in votes:
                user = vote.user
                subject = f'Nueva funcionalidad lanzada: {feature_request.title}'
                message = f'Hola {user.username}, tu voto por la funcionalidad "{feature_request.title}" ha sido lanzado.'
                from_email = 'admin@nexo.com'
                recipient_list = [user.email]
                send_mail(subject, message, from_email, recipient_list)
    except FeatureRequest.DoesNotExist:
        self.update_state(state='FAILURE', meta={'error': f"FeatureRequest con ID {feature_request_id} no encontrado"})
