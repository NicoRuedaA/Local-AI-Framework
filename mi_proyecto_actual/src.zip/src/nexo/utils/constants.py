STATUS_CHOICES = (
    ('Bajo revisión', 'Bajo revisión'),
    ('Planeado', 'Planeado'),
    ('En desarrollo', 'En desarrollo'),
    ('Lanzado', 'Lanzado'),
)
