from django.contrib import admin
from .models import FeatureRequest, Vote

admin.site.register(FeatureRequest)
admin.site.register(Vote)
