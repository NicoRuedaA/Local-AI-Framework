from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import FeatureViewSet, VoteAPIView

router = DefaultRouter()
router.register(r'features', FeatureViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('features/<int:feature_request_id>/vote/', VoteAPIView.as_view({'post': 'create'}), name='feature-vote'),
]
