from django.db.models import F
from rest_framework.response import Response
from rest_framework import status, permissions
from rest_framework.viewsets import ModelViewSet
from .models import FeatureRequest, Vote
from .serializers import FeatureRequestSerializer, VoteSerializer

class FeatureViewSet(ModelViewSet):
    queryset = FeatureRequest.objects.all()
    serializer_class = FeatureRequestSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

class VoteAPIView(viewsets.ViewSet):
    permission_classes = [permissions.IsAuthenticated]

    def create(self, request):
        user = request.user
        feature_request_id = request.data.get('feature_request')
        try:
            feature_request = FeatureRequest.objects.select_for_update().get(id=feature_request_id)
        except FeatureRequest.DoesNotExist:
            return Response({'detail': 'Feature request not found'}, status=status.HTTP_404_NOT_FOUND)

        if not feature_request.is_public and not user.has_perm('features.vote_feature', feature_request):
            return Response({'detail': 'This feature request is not public'}, status=status.HTTP_403_FORBIDDEN)

        vote, created = Vote.objects.get_or_create(user=user, feature_request=feature_request)
        if not created:
            return Response({'detail': 'You have already voted on this feature request'}, status=status.HTTP_400_BAD_REQUEST)

        send_notification_on_feature_request_status_change(feature_request_id)
        return Response({'detail': 'Vote successful'}, status=status.HTTP_201_CREATED)
