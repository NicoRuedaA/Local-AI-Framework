from django.test import TestCase
from rest_framework import status
from .models import FeatureRequest

class FeatureRequestTestCase(TestCase):
    def test_feature_request_creation(self):
        user = User.objects.create(username='testuser', password='password123')
        response = self.client.post('/api/features/', {'title': 'Test Feature Request', 'description': 'This is a test feature request'}, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_feature_request_list(self):
        user = User.objects.create(username='testuser', password='password123')
        response = self.client.get('/api/features/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
