from django.contrib import admin
from django.urls import path, include from rest_framework.routers import DefaultRouter from .views import FeatureViewSet, VoteAPIView router = DefaultRouter() router.register(r'features', FeatureViewSet) router.register(r'votes', VoteAPIView) urlpatterns = [ path('admin/', admin.site.urls), path('api/', include(router.urls)), ]
